/* Estructura "constant" del joc */
var gameConfig = {
    liveLook: ["monster5.png", "monster4.png", "monster3.png", "monster2.png", "monster1.png", "monster0.png"],
    wordsToGuess: ["elefant", "criatura", "llapis", "maduixa"],
    numberOfLives: 5,
}

/* Estructura per tenir controlat en tot moment l'estat del joc */
var gameStatus = {
    status: "playing",
    lives: gameConfig.numberOfLives,
    wordToGuess: "",
    wordCompleted: "",
}

//Creem un objecte per poder guardar les funcions anonimes dle addEventListener

var globalStruct = {};
globalStruct.lletra = function(event){ lletra(event) };


//Al carregar la pagina iniciem el joc

window.addEventListener("load", inici, false);


//Funcio per iniciar un nou joc
function inici()
{
    //cada cop que iniciem un nou joc resetegem les variables d'aquest
    reset();


    //Mostrem el missatge d'inici
    document.getElementById("info").style.display = "initial";
    document.getElementById("welcome").style.display = "initial";


    //Afegim els events que el joc te
    eventListener();

}


//Funcio per definir els events dels botons o per teclat
function eventListener()
{
    document.getElementById("btn_ok").addEventListener("click", resetMissatges, false);
    document.getElementById("new_game").addEventListener("click", inici, false);
    document.getElementsByTagName("body")[0].addEventListener("keyup", globalStruct.lletra, false);
    document.getElementById("clue").addEventListener("mouseleave", sortirPista, false);
    document.getElementById("clue").addEventListener("mouseenter", mostrarPista, false);
}


//Funcio del click continuar del missatge d'informació
function resetMissatges()
{
    document.getElementById("info").style.display = "";
    document.getElementById("welcome").style.display = "";
    document.getElementById("game_success").style.display = "";
    document.getElementById("game_fail").style.display = "";
}


//Funcio per a mostrar una pista
function mostrarPista()
{
    //Agafem un lletra random de la paraula
    var pista = gameStatus.wordToGuess.charAt(Math.round(Math.random()*(gameStatus.wordToGuess.length - 1)));

    //Comprobem si aquesta pista esta en la paraula completada
    if(gameStatus.wordCompleted.indexOf(pista) != -1)
    {
        //Si la pista esta en la paraula compltada tornem a cridar la funcio per agafar una pista nova
        mostrarPista();
    }
    else //Si la pista no esta en la paraula la mostrem
    {
        document.getElementById("clue").innerHTML = pista;
    }
}


//Funcio per agafar una lletra per teclat
function lletra(event)
{
    //Comprobem si es una lletra
    if (event.key >= 'a' && event.key <= 'z')
    {
        //Si la lletra no esta en la paraula restem una vida
        if(gameStatus.wordToGuess.indexOf(event.key) == -1)
        {
            restarVida();
        }
        else //Sino la imprimim
        {
            var temporal = "";

            for (let index = 0; index < gameStatus.wordCompleted.length; index++) 
            {
                if(gameStatus.wordCompleted.charAt(index) == '_' && gameStatus.wordToGuess.charAt(index) == event.key)
                {
                    temporal = temporal + gameStatus.wordToGuess.charAt(index);
                }
                else if(gameStatus.wordCompleted.charAt(index) != '_')
                {
                    temporal = temporal + gameStatus.wordCompleted.charAt(index);
                }
                else
                {
                    temporal = temporal + "_";
                }
            }
            gameStatus.wordCompleted = temporal;
            document.getElementById("letters").innerHTML = gameStatus.wordCompleted;

            //Si la paraula esta completada acabem la partida
            if(gameStatus.wordCompleted == gameStatus.wordToGuess)
            {
                fiPartida();
            }
        }
    }
}


//Funcio que et posa l'interrogant al sortir de pista i et resta vida
function sortirPista()
{
    //A pista mostrem interrogant per si sortim del boto
    document.getElementById("clue").innerHTML = '<span>?</span>';

    //Si el joc no ha acabat restem vida
    if(gameStatus.status != "end")
    {
        restarVida();
    }
    else //Si ha acabat li triem l'event
    {
        document.getElementById("clue").removeEventListener("mouseleave", sortirPista, false);
    }
}

//Funcio per restar una vida
function restarVida()
{
    //Restem una vida i mostrem la quantitat de vides
    gameStatus.lives--;
    document.getElementById("lives").innerHTML = gameStatus.lives + " LIVES LEFT";

    //Mostem l'imatge del monstre corresponent a les vides gracies a l'array de monstres
    document.getElementById("monster").src = "./img/" + gameConfig.liveLook[gameStatus.lives];

    //Si vides es igual a 0 s'acaba la partida
    if (gameStatus.lives == 0)
    {
        fiPartida();
    }

}


//Funcio per acabar partida
function fiPartida()
{
    //Si vides es mes gran a 0 has guanyat i mostrem els misstges corresponents
    if (gameStatus.lives > 0)
    {
        document.getElementById("info").style.display = "initial";
        document.getElementById("game_success").style.display = "initial";
    }
    else //Si vides es igual a 0 has perdut i mostrem els misstges corresponents
    {
        document.getElementById("info").style.display = "initial";
        document.getElementById("game_fail").style.display = "initial";
    }

    //Retirem els events de la pagina perque el joc no pugui seguir
    document.getElementsByTagName("body")[0].removeEventListener("keyup", globalStruct.lletra, false);
    document.getElementById("clue").removeEventListener("mouseenter", mostrarPista, false);

    //Cambiem l'estat a acabat
    gameStatus.status = "end";
}


//Reset i inicialitzar variables
function reset()
{
    gameStatus.status = "playing";
    gameStatus.lives = gameConfig.numberOfLives;
    gameStatus.wordToGuess = gameConfig.wordsToGuess[Math.round(Math.random()*(gameConfig.wordsToGuess.length - 1))];
    gameStatus.wordCompleted = "";
    for (let index = 0; index < gameStatus.wordToGuess.length; index++) 
    {
        gameStatus.wordCompleted += "_";
    }
    document.getElementById("letters").innerHTML = gameStatus.wordCompleted;
    document.getElementById("monster").src = "./img/" + gameConfig.liveLook[gameStatus.lives];
    document.getElementById("lives").innerHTML = gameStatus.lives + " LIVES LEFT";
    document.getElementById("clue").innerHTML = '<span>?</span>';

}